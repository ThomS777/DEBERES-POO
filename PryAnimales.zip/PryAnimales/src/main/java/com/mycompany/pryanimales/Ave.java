
package com.mycompany.pryanimales;

public class Ave extends  Animal{
    public double envergaduraAlas;
    public Ave(String nombre, int edad,double envergaduraAlas) {
        super(nombre, edad);
        this.envergaduraAlas =  envergaduraAlas;
    }
    public void volar (){
        System.out.println(nombre+" está volando con sus alas de envergadura:"+ envergaduraAlas + "cm");
    }
    
}
