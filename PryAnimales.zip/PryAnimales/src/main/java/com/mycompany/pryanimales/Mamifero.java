
package com.mycompany.pryanimales;


public class Mamifero extends Animal {
    public String tipoPelaje;
    
    public Mamifero(String nombre, int edad, String tipoPelaje) {
        super(nombre, edad);
        this.tipoPelaje = tipoPelaje;
    }
    public void amamantarCrias (){
        System.out.println(nombre+" de pelaje: " + tipoPelaje + " está amamantando a sus crias");
    }
    
}
