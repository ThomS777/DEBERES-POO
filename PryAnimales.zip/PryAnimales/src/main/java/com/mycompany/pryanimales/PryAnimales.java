

package com.mycompany.pryanimales;

import java.util.ArrayList;
import java.util.Scanner;

public class PryAnimales {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Animal> animales = new ArrayList<>();

        System.out.println("Ingrese los datos de los animales");

        System.out.println("\n--- Mamifero ---");
        System.out.print("Ingrese el nombre del mamifero: ");
        String nombreMamifero = scanner.nextLine();
        System.out.print("Ingrese la edad del mamifero: ");
        int edadMamifero = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Ingrese el tipo de pelaje: ");
        String tipoPelaje = scanner.nextLine();
        Mamifero mamifero = new Mamifero(nombreMamifero, edadMamifero, tipoPelaje);
        animales.add(mamifero);

        System.out.println("\n--- Ave ---");
        System.out.print("Ingrese el nombre del ave: ");
        String nombreAve = scanner.nextLine();
        System.out.print("Ingrese la edad del ave: ");
        int edadAve = scanner.nextInt();
        System.out.print("Ingrese la envergadura de las alas (en cm): ");
        double envergaduraAlas = scanner.nextDouble();
        scanner.nextLine();
        Ave ave = new Ave(nombreAve, edadAve, envergaduraAlas);
        animales.add(ave);

        System.out.println("\n--- Reptil ---");
        System.out.print("Ingrese el nombre del reptil: ");
        String nombreReptil = scanner.nextLine();
        System.out.print("Ingrese la edad del reptil: ");
        int edadReptil = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Ingrese el tipo de escamas: ");
        String tipoEscamas = scanner.nextLine();
        Reptil reptil = new Reptil(nombreReptil, edadReptil, tipoEscamas);
        animales.add(reptil);

        System.out.println("\n--- Informacion de los Animales ---");
        for (Animal animal : animales) {
            mostrarInformacion(animal);
            if (animal instanceof Mamifero) {
                Mamifero mamiferoAnimal = (Mamifero) animal;
                mamiferoAnimal.comer();
                mamiferoAnimal.amamantarCrias();
            }else if (animal instanceof Ave){
                Ave aveAnimal = (Ave) animal;
                aveAnimal.comer();
                aveAnimal.volar();
            }else if (animal instanceof Reptil){
                Reptil reptilAnimal = (Reptil) animal;
                reptilAnimal.comer();
                reptilAnimal.arrastrarse();
            }
        }

        scanner.close();
    }

    private static void mostrarInformacion(Animal animal) {
        if (animal instanceof Mamifero) {
            Mamifero mamifero = (Mamifero) animal;
            System.out.println("Mamifero: " + mamifero.nombre + " Edad: " + mamifero.edad + " Pelaje: " + mamifero.tipoPelaje);
        } else if (animal instanceof Ave) {
            Ave ave = (Ave) animal;
            System.out.println("Ave: " + ave.nombre + " Edad: " + ave.edad + " Envergadura de alas: " + ave.envergaduraAlas + " cm");
        } else if (animal instanceof Reptil) {
            Reptil reptil = (Reptil) animal;
            System.out.println("Reptil: " + reptil.nombre + " Edad: " + reptil.edad + " Escamas: " + reptil.tipoEscamas);
        } else {
            System.out.println("Animal: " + animal.nombre + " Edad: " + animal.edad);
        }
    }
}